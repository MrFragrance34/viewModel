﻿using System;
using ClassLibrary4;

namespace ViewModel
{
    public class UsersDB : BaseDB
    {
        public UserList SelectAll()
        {
            command.CommandText = "SELECT * FROM Users";
            UserList list = new UserList(base.Select());
            return list;
        }

        public override BaseEntity NewEntity()
        {
            return new User();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            User user = entity as User;
            user.DisplayName = reader["DisplayName"].ToString();
            user.Email = reader["Email"].ToString();
            user.PasswordHash = reader["PasswordHash"].ToString();
            user.JoinDate = Convert.ToDateTime(reader["JoinDate"]);

            base.CreateModel(entity);
            return entity;
        }
    }
}