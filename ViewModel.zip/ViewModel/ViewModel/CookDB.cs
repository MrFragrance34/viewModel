﻿using System;
using ClassLibrary4;

namespace ViewModel
{
    public class CooksDB : BaseDB
    {
        public CookList SelectAll()
        {
            command.CommandText = "SELECT * FROM Cooks";
            CookList list = new CookList(base.Select());
            return list;
        }

        public override BaseEntity NewEntity()
        {
            return new Cook();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Cook cook = entity as Cook;
            cook.Bio = reader["Bio"].ToString();
            cook.ProfilePicPath = reader["ProfilePicPath"].ToString();

            base.CreateModel(entity);
            return entity;
        }
    }
}