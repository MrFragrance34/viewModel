﻿using System;
using ClassLibrary4;

namespace ViewModel
{
    public class CategoriesDB : BaseDB
    {
        public CategoryList SelectAll()
        {
            command.CommandText = "SELECT * FROM Categories";
            CategoryList list = new CategoryList(base.Select());
            return list;
        }

        public override BaseEntity NewEntity()
        {
            return new Category();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Category category = entity as Category;
            category.CategoryName = reader["CategoryName"].ToString();

            base.CreateModel(entity);
            return entity;
        }
    }
}